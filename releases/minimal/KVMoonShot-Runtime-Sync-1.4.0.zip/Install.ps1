$ErrorActionPreference = 'Stop'
Set-Location $PSScriptRoot
if (-not (Get-Command node -ErrorAction SilentlyContinue)) {
  throw 'Install Node.js 18+ from https://nodejs.org/'
}
$major = [int](node -p "process.versions.node.split('.')[0]")
if ($major -lt 18) { throw "Node.js 18+ required (got $(node -v))" }
Write-Host 'Installing KVMoonShot runtime sync...'
npm install --no-fund --no-audit
if (-not (Test-Path 'node_modules/@kvmoonshot/kvmswap-native/lib/bootstrap.js')) {
  throw 'Native package did not install correctly.'
}
Write-Host 'Done.'
