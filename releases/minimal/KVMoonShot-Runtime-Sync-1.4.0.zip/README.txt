KVMoonShot Runtime Sync (1.4.0)
=====================================

Minimal bundle (~20 KB zip). Same native install/bootstrap as trial SDK npm postinstall.
This is not the full trading desk app (that build is optional and much larger).

Requirements: Node.js 18+ (https://nodejs.org/)

Windows: extract, then double-click Install.cmd (or run Install.ps1)
macOS/Linux: extract, then run ./install.sh

The .tgz is bundled for offline install (no registry fetch required).
