@echo off
setlocal EnableExtensions
where node >nul 2>&1 || (
  echo Node.js 18+ is required. Install from https://nodejs.org/ then run this again.
  exit /b 1
)
for /f "delims=" %%v in ('node -p "Number(process.versions.node.split('.')[0])"') do set NODE_MAJOR=%%v
if %NODE_MAJOR% LSS 18 (
  echo Node.js 18+ is required. Current:
  node -v
  exit /b 1
)
cd /d "%~dp0"
echo Installing KVMoonShot runtime sync...
call npm install --no-fund --no-audit
if errorlevel 1 (
  echo npm install failed.
  exit /b 1
)
if not exist "node_modules\@kvmoonshot\kvmswap-native\lib\bootstrap.js" (
  echo Native package did not install correctly.
  exit /b 1
)
echo Done.
endlocal
