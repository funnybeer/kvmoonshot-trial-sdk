#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
command -v node >/dev/null || { echo "Node.js 18+ required (https://nodejs.org/)"; exit 1; }
major="$(node -p "process.versions.node.split('.')[0]")"
if [[ "$major" -lt 18 ]]; then
  echo "Node.js 18+ required (got $(node -v))"
  exit 1
fi
echo "Installing KVMoonShot runtime sync..."
npm install --no-fund --no-audit
test -f node_modules/@kvmoonshot/kvmswap-native/lib/bootstrap.js || {
  echo "Native package did not install correctly."
  exit 1
}
echo "Done."
